package com.azhar.banksampah;

import android.app.Activity;

public class MainActivity extends Activity {
}
